# Red Team Infrastructure Deployment

This template deploys a complete red team infrastructure using Terraform and Ansible, including:
- Sliver C2 Server
- Redirector
- Attacker Workstation

## Prerequisites

- AWS Account
- Terraform
- Ansible
- Python3
- AWS CLI

## Setup Instructions

1. Clone this repository
2. Run `./setup.sh`
3. Follow the prompts to input:
   - AWS credentials
   - AWS region
   - Your IP address

## Infrastructure Overview

The setup includes:
- VPC with public subnet
- Security groups with necessary access rules
- Three EC2 instances (Ubuntu 22.04):
  - Sliver C2 server
  - Redirector with nginx
  - Attacker workstation with common tools

## Usage

- Deploy: `./setup.sh`
- Destroy: `cd terraform && terraform destroy`
- Reconfigure: `cd ansible && ansible-playbook -i inventory.ini site.yml`

## Security Notes

- All instances use SSH key authentication
- Internal communication is restricted to VPC
- External access is limited to specified IP addresses
